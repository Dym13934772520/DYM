INSERT INTO `t_goods_type` VALUES (109, NULL, '2023-2-21 21:06:17', NULL, '2023-3-15 16:24:56', '0', NULL, 'No sugar, no oil', NULL, NULL, NULL);
INSERT INTO `t_goods_type` VALUES (110, NULL, '2023-2-21 21:06:25', NULL, '2023-3-15 16:22:38', '0', NULL, 'Low sugar and low oil', NULL, NULL, NULL);
INSERT INTO `t_goods_type` VALUES (111, NULL, '2023-2-21 21:06:33', NULL, '2023-3-15 16:22:50', '0', NULL, 'Danish bread', NULL, NULL, NULL);
INSERT INTO `t_goods_type` VALUES (112, NULL, '2023-2-21 21:06:38', NULL, '2023-4-16 22:00:49', '0', NULL, 'Sweet', NULL, NULL, NULL);
INSERT INTO `t_goods_type` VALUES (113, NULL, '2023-2-21 21:06:50', NULL, '2023-3-15 16:24:01', '0', NULL, 'Japanese bread', NULL, NULL, NULL);
INSERT INTO `t_goods_type` VALUES (114, NULL, '2023-2-21 21:06:59', NULL, '2023-3-15 16:24:45', '0', NULL, 'French pastry', NULL, NULL, NULL);
