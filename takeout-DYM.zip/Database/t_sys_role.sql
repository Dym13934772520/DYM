INSERT INTO `t_sys_role` VALUES (0, NULL, NULL, NULL, NULL, '0', NULL, NULL, 'Administrator', NULL, NULL);
INSERT INTO `t_sys_role` VALUES (1, NULL, NULL, NULL, NULL, '0', NULL, NULL, 'Customer', NULL, NULL);
INSERT INTO `t_sys_role` VALUES (2, NULL, NULL, NULL, NULL, '0', NULL, NULL, 'Merchant', NULL, NULL);
INSERT INTO `t_sys_role` VALUES (3, NULL, NULL, NULL, NULL, '0', NULL, NULL, 'Delivery man', NULL, NULL);
