INSERT INTO `t_sys_menu` VALUES (1, NULL, NULL, NULL, NULL, '0', NULL, NULL, 0, 'user delete', '/user/delete', NULL, NULL, NULL);
INSERT INTO `t_sys_menu` VALUES (2, NULL, NULL, NULL, NULL, '0', NULL, NULL, 1, 'user delete', '/user/delete', NULL, NULL, NULL);
INSERT INTO `t_sys_menu` VALUES (3, NULL, NULL, NULL, NULL, '0', NULL, NULL, 0, 'user update', '/user/update', NULL, NULL, NULL);
INSERT INTO `t_sys_menu` VALUES (4, NULL, NULL, NULL, NULL, '0', NULL, NULL, 0, 'user findByModal', '/user/findByModal', NULL, NULL, NULL);
