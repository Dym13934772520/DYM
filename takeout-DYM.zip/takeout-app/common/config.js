export default {
	websoketUrl:""
}