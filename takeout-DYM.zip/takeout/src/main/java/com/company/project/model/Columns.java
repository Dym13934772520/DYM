package com.company.project.model;

/**
 * 返回前端的列
 */
public class Columns {

    //字段名称
    private String field;

    //字段备注
    private String title;

    //宽度
    private String width;

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }
}
