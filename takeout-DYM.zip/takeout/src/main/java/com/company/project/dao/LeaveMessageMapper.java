package com.company.project.dao;

import com.company.project.core.Mapper;
import com.company.project.model.LeaveMessage;

public interface LeaveMessageMapper extends Mapper<LeaveMessage> {
}