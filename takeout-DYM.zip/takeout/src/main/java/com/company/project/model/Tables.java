package com.company.project.model;

/**
 * 返回前端的表
 */
public class Tables {

    //表名称
    private String tableName;

    //表备注
    private String tableComment;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getTableComment() {
        return tableComment;
    }

    public void setTableComment(String tableComment) {
        this.tableComment = tableComment;
    }
}
