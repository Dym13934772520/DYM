package com.company.project.common;


public class BaseParam extends BaseBean {

}
