package com.company.project.dao;

import com.company.project.core.Mapper;
import com.company.project.model.Shop;

import java.util.List;

public interface ShopMapper extends Mapper<Shop> {

    List<Shop> list(Shop shop);

    List<Shop> findAllByModal(Shop shop);

    Shop detail(Long id);
}