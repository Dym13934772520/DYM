package com.company.project.service;
import com.company.project.model.LeaveMessage;
import com.company.project.core.Service;

public interface LeaveMessageService extends Service<LeaveMessage> {

}
