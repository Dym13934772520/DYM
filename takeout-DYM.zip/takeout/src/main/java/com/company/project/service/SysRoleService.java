package com.company.project.service;
import com.company.project.model.SysRole;
import com.company.project.core.Service;

public interface SysRoleService extends Service<SysRole> {

}
