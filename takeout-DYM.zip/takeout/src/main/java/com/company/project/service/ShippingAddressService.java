package com.company.project.service;
import com.company.project.model.ShippingAddress;
import com.company.project.core.Service;

public interface ShippingAddressService extends Service<ShippingAddress> {

}
