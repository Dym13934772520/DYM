package com.company.project.service;
import com.company.project.model.Cover;
import com.company.project.core.Service;

public interface CoverService extends Service<Cover> {

}
